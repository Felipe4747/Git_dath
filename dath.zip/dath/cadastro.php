<?php
    session_start();
    include "conexao.php";
     if ($_SERVER['REQUEST_METHOD'] == 'POST') {
         $Nome = $_POST["nome"];
        $Email = $_POST["email"];
        $Senha = $_POST["pswd"];
        $Tel = $_POST["tel"];
        $CPF = $_POST["cpf"];
        $Nasc = $_POST["nasc"];
        $Sangue = $_POST["sangue"];
        $Sexo = $_POST["sexo"];

        try {
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "insert into usuario (nome, email, senha, tel, cpf, nasc, tipo_s, sexo)
            values('$Nome','$Email',sha('$Senha'),'$Tel','$CPF','$Nasc','$Sangue','$Sexo')";
            // use exec() because no results are returned
            $conn->exec($sql);
            echo "Sucesso!";
            $_SESSION['usuario'] = $Nome;
            $_SESSION['email'] = $Email;
            header('Location: perfil.php');
        }
        catch(PDOException $e)
        {
            echo $sql . "<br>" . $e->getMessage();
        }
        }
        $conn = null;
    ?>