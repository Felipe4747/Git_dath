<?php

session_start();
include("conexao.php");

if(empty($_POST['emailmodal']) || empty($_POST['pwdmodal'])) {
    header('Location: index.php');
    exit();
}

$email = $_POST['emailmodal'];
$senha = $_POST['pwdmodal'];

$sql = "select count(*) from usuario where email = '$email' and senha = sha('$senha')";
$result = $conn->prepare($sql);
$result->execute();



$row = $result->fetchColumn();
if ($row == 1) {
    $sqlnome = "select nome from usuario where email = '$email'";
    $resultnome = $conn->query($sqlnome);
    $resultnome->execute();
    $nome = $resultnome->fetchColumn();
    
    $_SESSION['usuario'] = $nome;
    $_SESSION['email'] = $email;
    header('Location: perfil.php');
    exit();
} else {
    header('Location: index.php');
}
?>